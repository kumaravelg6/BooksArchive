//
//  DataProvider.swift
//  BookInfo
//
//  Created by Kumaravel G on 16/07/19.
//  Copyright © 2019 Test. All rights reserved.
//

import Foundation

enum DataResult<T>{
    case success(result: T)
    case failure(error: String?)
}

typealias CompletionHandler = (_ result: DataResult<[BookDetails]>) -> Void

class BookDetails: Codable {
    var id : String
    var book_title : String
    var author_name : String
    var genre : String
    var publisher : String
    var author_country : String
    var sold_count : Int
    var image_url : String
}

class list : Codable {
    var list : [BookDetails]
}

class DataProvider {
    
    static func fetchData(completion: @escaping CompletionHandler){
        let task = URLSession.shared.dataTask(with: NSURL(string: "http://android.jiny.mockable.io/getAll")! as URL, completionHandler: { (data, response, error) -> Void in
            do{
                let decoder = JSONDecoder()
                let model = try decoder.decode(list.self, from:data!) //Decode JSON Response Data
                
                //let str = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.allowFragments) as! [String:AnyObject]
                //print(str)
                print(model.list)
                completion(.success(result: model.list))

            } catch {
                completion(.failure(error: error.localizedDescription))
                fatalError("json error: \(error)")
            }
        })
        task.resume()
    }
}
