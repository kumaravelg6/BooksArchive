//
//  CustomCells.swift
//  BookInfo
//
//  Created by Kumaravel G on 17/07/19.
//  Copyright © 2019 Test. All rights reserved.
//

import UIKit

class BookListCell : UITableViewCell {
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblAuthor: UILabel!
    @IBOutlet weak var lblGenre: UILabel!
    @IBOutlet weak var imgBook: UIImageView!
}
