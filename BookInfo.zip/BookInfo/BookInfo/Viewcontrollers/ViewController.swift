//
//  ViewController.swift
//  BookInfo
//
//  Created by Kumaravel on 16/7/19.
//  Copyright © 2019 Test. All rights reserved.
//

import UIKit

enum filterTypes : Int {
    case Author = 0
    case Genre
    case Country
    case Publisher
    static var allValues = [filterTypes.Author, .Genre, .Country, .Publisher]
}

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var btnCreate : UIButton!
    @IBOutlet weak var tableView : UITableView!
    var bookDetails = [BookDetails]()
    var filterArray = [String]()
    // Initial filter type is author
    var selectedFilterType = filterTypes.Author
    
    override func viewDidLoad() {
        super.viewDidLoad()
            tableView.delegate = self
            tableView.dataSource = self
            tableView.isHidden = true
            self.view.setNeedsLayout()
            setupNavigationBar()
        }
    
    // Do any additional setup after loading the view.
    func showTableView() {
        self.tableView.isHidden = false
        self.btnCreate.isHidden = true
        tableView.reloadData()
    }
    
    func setupNavigationBar() {
        
        let refresh = UIBarButtonItem(barButtonSystemItem: .refresh, target: self, action: #selector(refreshTapped))
        let view = UIView(frame: CGRect(x:0, y:0, width:60, height:40))
        view.backgroundColor = UIColor.clear
        let customButton = UIButton(frame: CGRect.init(x: 5, y: 5, width: 50, height: 30))
        customButton.setTitle("Filter", for: .normal)
        customButton.setTitleColor(.black, for: .normal)
        customButton.addTarget(self, action: #selector(showFilterPopup(_:)), for: .touchUpInside)
        view.addSubview(customButton)
        let filter = UIBarButtonItem(customView: view)
        self.title = "Books Archive"
        self.navigationItem.rightBarButtonItems = [refresh, filter]
        
    }
    
    //MARK:- Custom Actions
    @objc func refreshTapped() {
        getData()
    }
    
    @IBAction func btnCreate_clicked(sender : UIButton){
        getData()
    }
    
    //MARK:- Filter Popup related
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
    }
    
    @objc func showFilterPopup(_ sender: UIView) {
        let controller = ArrayChoiceTableViewController(filterTypes.allValues) { (filterType) in
            self.selectedFilterType = filterType
            self.filterData(type: self.selectedFilterType)
            self.tableView.reloadData()
        }
        controller.preferredContentSize = CGSize(width: 300, height: 200)
        showPopup(controller, sourceView: sender)
    }
    
    private func showPopup(_ controller: UIViewController, sourceView: UIView) {
        let presentationController = AlwaysPresentAsPopover.configurePresentation(forController: controller)
        presentationController.sourceView = sourceView
        presentationController.sourceRect = sourceView.bounds
        presentationController.permittedArrowDirections = [.down, .up]
        self.present(controller, animated: true)
    }
    
   
    //MARK:- TableView related
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.filterArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellIdentifier")!
        let txtLabel = filterArray[indexPath.row]
        cell.textLabel?.text = txtLabel.capitalizingFirstLetter()
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "BookListViewController") as? BookListViewController {
            vc.bookList = self.bookDetails
            vc.selectedText = filterArray[indexPath.row]
            vc.selectedFilterType = selectedFilterType
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    // MARK:- Data handling
    func getData() {
        DataProvider.fetchData { (result) in
            switch result {
            case .success(let data) :
                self.bookDetails = data
                self.filterData(type: self.selectedFilterType)
                DispatchQueue.main.async {
                    self.showTableView()
                }
            case .failure(let error):
                print(error ?? "")
            }
        }
    }
    
    func filterData(type : filterTypes) {
        switch type {
        case .Author:
            let mappedArray = self.bookDetails.compactMap { $0.author_name }
            filterArray = mappedArray.unique()
        case .Genre:
            let mappedArray = self.bookDetails.compactMap { $0.genre.lowercased() }
            filterArray = mappedArray.unique()
        case .Country:
            let mappedArray = self.bookDetails.compactMap { $0.author_country }
            filterArray = mappedArray.unique()
        case .Publisher:
            let mappedArray = self.bookDetails.compactMap { $0.publisher.lowercased() }
            filterArray = mappedArray.unique()
        }
    }
}


