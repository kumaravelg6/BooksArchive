//
//  BookListViewController.swift
//  BookInfo
//
//  Created by Kumaravel G on 17/07/19.
//  Copyright © 2019 Test. All rights reserved.
//

import UIKit

class BookListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate {
    
    var bookList : [BookDetails] = []
    var searchList : [BookDetails] = []
    var selectedFilterType : filterTypes?
    var selectedText : String?
    @IBOutlet weak var tableView : UITableView!
    @IBOutlet weak var searchBar : UISearchBar!
    // For background fetch
    var task: URLSessionDownloadTask!
    var session: URLSession!
    var cache:NSCache<AnyObject, AnyObject>!
    var searchActive : Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        searchBar.delegate = self
        
        self.title = "Books Archive"
        self.navigationItem.backBarButtonItem?.title = ""
        self.cache = NSCache()
        session = URLSession.shared
        task = URLSessionDownloadTask()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if searchBar.text != "" {
            searchActive = true
            self.searchData(searchText: searchBar.text ?? "")
        } else {
            if let filterText = selectedText {
                self.getBookList(filterText: filterText)
                tableView.reloadData()
            }
        }
    }
    
    //MARK:- TableView delegate methods
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if(searchActive) {
            return searchList.count
        }
        return self.bookList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "bookListCell") as! BookListCell
        var imageURL = ""
        if(searchActive) {
            imageURL = self.searchList[indexPath.row].image_url
            cell.lblAuthor.text = self.searchList[indexPath.row].author_name.capitalizingFirstLetter()
            cell.lblGenre.text = self.searchList[indexPath.row].genre.capitalizingFirstLetter()
            cell.lblTitle.text = self.searchList[indexPath.row].book_title
        }
        else {
            imageURL = self.bookList[indexPath.row].image_url
            cell.lblAuthor.text = self.bookList[indexPath.row].author_name.capitalizingFirstLetter()
            cell.lblGenre.text = self.bookList[indexPath.row].genre.capitalizingFirstLetter()
            cell.lblTitle.text = self.bookList[indexPath.row].book_title
        }
        cell.imgBook.image = UIImage.init(named: "placeholder")
        cell.lblAuthor.sizeToFit()
        cell.lblAuthor.sizeToFit()
        
        if (self.cache.object(forKey: imageURL as AnyObject) != nil){
            // Use cache
            print("Cached image used, no need to download it")
            cell.imageView?.image = self.cache.object(forKey: imageURL as AnyObject) as? UIImage
            cell.setNeedsLayout()
        }else{
            let url:URL! = URL(string: imageURL)
            task = session.downloadTask(with: url, completionHandler: { (location, response, error) -> Void in
                if let data = try? Data(contentsOf: url){
                    DispatchQueue.main.async(execute: { () -> Void in
                        // Before we assign the image, check whether the current cell is visible
                        if let updateCell = tableView.cellForRow(at: indexPath) {
                            let img:UIImage! = UIImage(data: data)
                            updateCell.imageView?.image = img
                            updateCell.setNeedsLayout()
                            self.cache.setObject(img, forKey: imageURL as AnyObject)
                        }
                    })
                }
            })
            task.resume()
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "BookDetailsViewController") as? BookDetailsViewController {
            vc.bookDetails = self.bookList[indexPath.row]
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    //MARK:- Searchbar related methods
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        // Filter the array using the filter method
        searchData(searchText: searchText)
       
    }
    
    func searchData(searchText : String) {
        self.searchList = self.bookList.filter({( details: BookDetails) -> Bool in
            // to start, let's just search by name
            return (details.book_title.contains(searchText) == true)
        })
        if(self.searchList.count == 0){
            searchActive = false;
        } else {
            searchActive = true;
        }
        self.tableView.reloadData()
    }
    
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        searchActive = true;
    }
    
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
        searchActive = false;
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchActive = false;
    }
    
    private func searchBarSearchButtonClicked(searchBar: UISearchBar) {
        searchActive = false;
    }
    
    //MARK:- GetBookList
    func getBookList(filterText : String) {
        if let type = selectedFilterType {
        switch type {
            case .Author:
                bookList = bookList.filter { $0.author_name == filterText }
            case .Country:
                bookList = bookList.filter { $0.author_country == filterText }
            case .Genre:
                bookList = bookList.filter { $0.genre.lowercased() == filterText }
            case .Publisher:
                bookList = bookList.filter { $0.publisher.lowercased() == filterText }
            }
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}




