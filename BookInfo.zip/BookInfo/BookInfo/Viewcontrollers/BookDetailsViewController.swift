//
//  BookDetailsViewController.swift
//  BookInfo
//
//  Created by Kumaravel G on 17/07/19.
//  Copyright © 2019 Test. All rights reserved.
//

import UIKit

class BookDetailsViewController: UIViewController {

    var bookDetails : BookDetails?
    @IBOutlet weak var lblAbout: UILabel!
    @IBOutlet weak var lblAuthor: UILabel!
    @IBOutlet weak var lblGenre: UILabel!
    @IBOutlet weak var imgBook: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        // Do any additional setup after loading the view.
    }
    
    func setupUI() {
        self.navigationItem.backBarButtonItem?.title = ""
        if let bookDetail = bookDetails {
            self.title = bookDetail.book_title
            lblAuthor.text = bookDetail.author_name.capitalizingFirstLetter()
            lblGenre.text = bookDetail.genre.capitalizingFirstLetter()
            imgBook.loadFromURL(urlString: bookDetail.image_url)
            lblAbout.text = "About the book:\nPublisher: \(bookDetail.publisher.capitalizingFirstLetter()) \nSold count: \(bookDetail.sold_count)\nAuthor Country: \(bookDetail.author_country)"
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
